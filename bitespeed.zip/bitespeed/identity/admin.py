from django.contrib import admin
from .models import Contact

@admin.register(Contact)
class ContactAdmin(admin.ModelAdmin):
    list_display = ('id', 'phoneNumber', 'email', 'linkedId', 'linkPrecedence', 'createdAt', 'updatedAt', 'deletedAt')
    list_filter = ('linkPrecedence', 'createdAt', 'updatedAt', 'deletedAt')
    search_fields = ('phoneNumber', 'email')


