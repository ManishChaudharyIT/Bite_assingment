import json
from django.http import JsonResponse
from django.db.models import Q
from django.utils import timezone
from django.views.decorators.csrf import csrf_exempt
from .models import Contact

@csrf_exempt
def identify(request):
    if request.method == "POST":
        data = json.loads(request.body)
        email = data.get("email")
        phoneNumber = data.get("phoneNumber")

        contacts = Contact.objects.filter(Q(email=email) | Q(phoneNumber=phoneNumber))

        if contacts.exists():
            primary_contact = contacts.filter(linkPrecedence='primary').first()
            if not primary_contact:
                primary_contact = contacts.first()
            
            primary_emails = list(contacts.values_list('email', flat=True))
            primary_phone_numbers = list(contacts.values_list('phoneNumber', flat=True))
            secondary_contacts = contacts.exclude(id=primary_contact.id)

            response_data = {
                "contact": {
                    "primaryContactId": primary_contact.id,
                    "emails": primary_emails,
                    "phoneNumbers": primary_phone_numbers,
                    "secondaryContactIds": list(secondary_contacts.values_list('id', flat=True))
                }
            }
            return JsonResponse(response_data, status=200)
        else:
            new_contact = Contact.objects.create(
                phoneNumber=phoneNumber,
                email=email,
                linkPrecedence='primary',
                createdAt=timezone.now(),
                updatedAt=timezone.now()
            )
            response_data = {
                "contact": {
                    "primaryContactId": new_contact.id,
                    "emails": [email] if email else [],
                    "phoneNumbers": [phoneNumber] if phoneNumber else [],
                    "secondaryContactIds": []
                }
            }
            return JsonResponse(response_data, status=200)
    return JsonResponse({"error": "Invalid request method."}, status=400)
